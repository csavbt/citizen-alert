exports.handler = async (event)=>{
  if(event.httpMethod!=="POST") return { statusCode:405, body:"Méthode non autorisée" };
  const { id, status } = JSON.parse(event.body||"{}");
  if(!id||!status) return { statusCode:400, body:"id et status sont requis" };
  return { statusCode:200, headers:{ "Content-Type":"application/json; charset=utf-8" }, body: JSON.stringify({ id, status, updated:true }) };
};