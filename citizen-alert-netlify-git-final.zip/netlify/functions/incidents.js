const data=[
  { id:"demo-1", type:"security", status:"validated", title:"Alerte sécurité (démo)" },
  { id:"demo-2", type:"cyber", status:"submitted", title:"Phishing massif (démo)" }
];
exports.handler = async (event)=>{
  const url=new URL(event.rawUrl);
  const type=url.searchParams.get("type");
  const filtered= type? data.filter(d=>d.type===type): data;
  return { statusCode:200, headers:{ "Content-Type":"application/json; charset=utf-8" }, body: JSON.stringify(filtered) };
};