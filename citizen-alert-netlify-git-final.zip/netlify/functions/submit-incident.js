exports.handler = async (event)=>{
  if(event.httpMethod!=="POST") return { statusCode:405, body:"Méthode non autorisée" };
  const payload = JSON.parse(event.body||"{}");
  if(!payload.title||!payload.type){ return { statusCode:400, body:"title et type sont requis" }; }
  const created={ id:"tmp-"+Date.now(), ...payload, status:"submitted" };
  return { statusCode:201, headers:{ "Content-Type":"application/json; charset=utf-8" }, body: JSON.stringify(created) };
};