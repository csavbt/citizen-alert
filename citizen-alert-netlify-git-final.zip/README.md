Citizen-Alert — Netlify (Git + Functions)
Déploiement :
- Créez un repo GitHub et uploadez ces fichiers à la racine
- Netlify → Add new site → Import from Git
- Build settings: Publish directory = web ; Functions directory = netlify/functions
